import pygame, sys

def loading_bar(text):
    pygame.init()

    def draw_text(texte, font, couleur, x, y):
        img = font.render(texte, True, couleur)
        screen.blit(img, (x, y))

    screen= pygame.display.set_mode((0,0),pygame.FULLSCREEN)
    screen_width, screen_height = pygame.display.Info().current_w, pygame.display.Info().current_h
    clock = pygame.time.Clock()
    background = pygame.image.load("sprites/arcade/Loading Bar Background.png")
    bg_rect = background.get_rect(center=(screen_width // 2, screen_height // 2 + 120))
    loading_bar = pygame.image.load("sprites/arcade/Loading Bar.png")
    loading_bar_rect = loading_bar.get_rect(midleft=(screen_width // 2 - 360, screen_height // 2 + 120))
    loading_progress = 0
    loading_bar_width = 8
    font_lilitaone_80 = pygame.font.Font("fonts/LilitaOne-Regular.ttf", 80)

    while not loading_bar_width > 720:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill("#424340")
        text_width, text_height = font_lilitaone_80.size(text)
        draw_text(text, font_lilitaone_80, (184,203,208), screen_width // 2 - text_width // 2, screen_height // 2 - text_height // 2 - 70)
        multi = loading_progress // 100 + 2
        loading_progress += 1 * multi
        loading_bar_width = loading_progress
        loading_bar = pygame.transform.scale(loading_bar, (int(loading_bar_width), 150))
        loading_bar_rect = loading_bar.get_rect(midleft=(screen_width // 2 - 360, screen_height // 2 + 120))
        screen.blit(background, bg_rect)
        screen.blit(loading_bar, loading_bar_rect)

        pygame.display.update()
        clock.tick(60)